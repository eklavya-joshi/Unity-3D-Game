Note: This game might not start on some computers. I don't know why this occurs.

Extract all the zip files into the same folder.